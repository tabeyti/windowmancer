﻿using System.Collections.ObjectModel;
using Microsoft.Practices.Unity;
using System.Windows;
using Windowmancer.Models;
using Windowmancer.Practices;
using Windowmancer.Services;

namespace Windowmancer
{ 
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class EditorWindow : Window
  {
    // TODO: Temp
    private static IUnityContainer ServiceResolver { get; set; }
    private readonly ProfileManager _profileManager;
    private readonly WindowManager _windowManager;
    private readonly KeyHookManager _keyHookManager;
    private readonly ProcMonitor _procMonitor;
    
    public EditorWindow()
    {
      ServiceResolver = WMServiceResolver.Instance;

      // TODO: Temp
      _profileManager = ServiceResolver.Resolve<ProfileManager>();
      _windowManager = ServiceResolver.Resolve<WindowManager>();
      _keyHookManager = ServiceResolver.Resolve<KeyHookManager>();
      _procMonitor = ServiceResolver.Resolve<ProcMonitor>();

      InitializeComponent();
      Initialize();
    }

    private void Initialize()
    {
      this.ProfileListBox.ItemsSource = _profileManager.Profiles;
      this.ProfileListBox.SelectedItem = _profileManager.ActiveProfile;
      this.WindowConfigDataGrid.ItemsSource = _profileManager.ActiveProfile.Windows;
      this.ActiveWindowsGrid.ItemsSource = _procMonitor.ActiveWindowProcs;
      _procMonitor.Start();
    }
  }
}
